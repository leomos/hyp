var BooksController = function (model, view) {
  this.model = model;
  this.view = view;

  this.init();
};

BooksController.prototype = {

  init: function() {
  },

};